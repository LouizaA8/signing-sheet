import PDFDocument from 'pdfkit';

export function generatePDF(sheet, attendances) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ margin: 50 });
    const chunks = [];

    doc.on('data', chunk => chunks.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    // Header
    doc.fontSize(16).font('Helvetica-Bold').text('KSB', { align: 'center' });
    doc.fontSize(14).font('Helvetica-Bold').text(sheet.title, { align: 'center' });
    doc.fontSize(11).font('Helvetica').text(sheet.location, { align: 'center' });
    doc.fontSize(10).text(sheet.dates.join(' - '), { align: 'center' });

    doc.moveDown(1);

    // Table
    const tableTop = doc.y;
    const col1X = 50;
    const col2X = 200;
    const signatureWidth = 70;
    const rowHeight = 60;

    // Headers
    doc.fontSize(10).font('Helvetica-Bold');
    doc.text('Name', col1X, tableTop);
    
    sheet.dates.forEach((date, idx) => {
      const x = col2X + idx * signatureWidth;
      doc.text(date, x, tableTop);
    });

    doc.moveTo(50, tableTop + 20).lineTo(550, tableTop + 20).stroke();

    // Rows
    let currentY = tableTop + 30;
    const pageHeight = doc.page.height - 50;

    attendances.forEach((attendance, idx) => {
      if (currentY + rowHeight > pageHeight) {
        doc.addPage();
        currentY = 50;
      }

      // Name
      doc.fontSize(9).font('Helvetica').text(attendance.name, col1X, currentY, { width: 140 });

      // Signatures for each date
      sheet.dates.forEach((date, dateIdx) => {
        const x = col2X + dateIdx * signatureWidth;
        const attended = attendance.dates_attended.includes(date);

        if (attended && attendance.signature) {
          // Parse base64 image
          try {
            const buf = Buffer.from(attendance.signature.split(',')[1] || attendance.signature, 'base64');
            doc.image(buf, x, currentY, { width: 60, height: 50 });
          } catch (err) {
            // Signature invalid, leave blank
          }
        }
      });

      currentY += rowHeight;
    });

    doc.end();
  });
}
