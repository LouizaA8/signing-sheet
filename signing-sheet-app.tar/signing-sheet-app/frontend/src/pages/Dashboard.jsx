import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

function Dashboard({ user }) {
  const [title, setTitle] = useState('');
  const [location, setLocation] = useState('');
  const [dates, setDates] = useState(['', '', '']);
  const [deadline, setDeadline] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleDateChange = (index, value) => {
    const newDates = [...dates];
    newDates[index] = value;
    setDates(newDates);
  };

  const handleAddDate = () => {
    setDates([...dates, '']);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    const filledDates = dates.filter(d => d);
    if (!title || !location || filledDates.length === 0 || !deadline) {
      setError('Please fill in all fields');
      return;
    }

    setLoading(true);

    try {
      const res = await axios.post('/api/sheets', {
        title,
        location,
        dates: filledDates,
        submission_deadline: deadline
      });

      setSuccess(`Sheet created! Share this link: /sheets/${res.data.id}`);
      setTimeout(() => {
        navigate(`/admin/sheets/${res.data.id}`);
      }, 2000);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to create sheet');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    window.location.href = '/login';
  };

  return (
    <div>
      <div className="header">
        <div className="nav">
          <div className="logo">KSB Signing Sheet</div>
          <div>
            <span>{user.name}</span>
            <button onClick={handleLogout} style={{ marginLeft: '20px' }}>
              Logout
            </button>
          </div>
        </div>
      </div>

      <div className="container" style={{ maxWidth: '600px' }}>
        <h2>Create Signing Sheet</h2>

        {error && <div className="error">{error}</div>}
        {success && <div className="success">{success}</div>}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Event Title</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Sugar Board Strategy Meeting"
            />
          </div>

          <div className="form-group">
            <label>Location</label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="e.g., Nairobi HQ"
            />
          </div>

          <div className="form-group">
            <label>Event Dates</label>
            {dates.map((date, idx) => (
              <input
                key={idx}
                type="date"
                value={date}
                onChange={(e) => handleDateChange(idx, e.target.value)}
                style={{ marginBottom: '10px', display: 'block' }}
              />
            ))}
            <button type="button" onClick={handleAddDate} style={{ marginTop: '10px' }}>
              Add Date
            </button>
          </div>

          <div className="form-group">
            <label>Submission Deadline</label>
            <input
              type="datetime-local"
              value={deadline}
              onChange={(e) => setDeadline(e.target.value)}
            />
          </div>

          <button type="submit" disabled={loading}>
            {loading ? 'Creating...' : 'Create Sheet'}
          </button>
        </form>
      </div>
    </div>
  );
}

export default Dashboard;
