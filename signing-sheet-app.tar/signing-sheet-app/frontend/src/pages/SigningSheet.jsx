import { useState, useEffect, useRef } from 'react';
import { useParams } from 'react-router-dom';
import SignaturePad from 'signature_pad';
import axios from 'axios';

function SigningSheet() {
  const { id } = useParams();
  const [sheet, setSheet] = useState(null);
  const [user, setUser] = useState(null);
  const [isGuest, setIsGuest] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [selectedDates, setSelectedDates] = useState([]);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  const [pageLoading, setPageLoading] = useState(true);
  const canvasRef = useRef(null);
  const signaturePadRef = useRef(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    const fetchSheet = async () => {
      try {
        const res = await axios.get(`/api/sheets/${id}`);
        setSheet(res.data.sheet);

        if (token) {
          const userRes = await axios.get('/api/auth/me', {
            headers: { Authorization: `Bearer ${token}` }
          });
          setUser(userRes.data);
          setName(userRes.data.name);
          setEmail(userRes.data.email);
          setIsGuest(false);
        }
      } catch (err) {
        setError('Failed to load sheet');
      } finally {
        setPageLoading(false);
      }
    };

    fetchSheet();
  }, [id]);

  const initSignaturePad = () => {
    if (canvasRef.current && !signaturePadRef.current) {
      signaturePadRef.current = new SignaturePad(canvasRef.current, {
        backgroundColor: 'rgb(255,255,255)'
      });
    }
  };

  const handleClearSignature = () => {
    if (signaturePadRef.current) {
      signaturePadRef.current.clear();
    }
  };

  const handleDateToggle = (date) => {
    if (selectedDates.includes(date)) {
      setSelectedDates(selectedDates.filter(d => d !== date));
    } else {
      setSelectedDates([...selectedDates, date]);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!name || !email) {
      setError('Name and email are required');
      return;
    }

    if (selectedDates.length === 0) {
      setError('Please select at least one date');
      return;
    }

    if (!signaturePadRef.current || signaturePadRef.current.isEmpty()) {
      setError('Please draw your signature');
      return;
    }

    setLoading(true);

    try {
      const signature = signaturePadRef.current.toDataURL('image/png');
      await axios.post('/api/attendances', {
        sheet_id: id,
        name,
        email,
        signature,
        dates_attended: selectedDates,
        user_id: user?.id || null
      });

      setSuccess('Signature submitted successfully!');
      setTimeout(() => {
        window.location.reload();
      }, 2000);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to submit signature');
    } finally {
      setLoading(false);
    }
  };

  if (pageLoading) return <div className="container">Loading...</div>;
  if (!sheet) return <div className="container error">Sheet not found</div>;

  return (
    <div>
      <div className="header">
        <div className="nav">
          <div className="logo">KSB Signing Sheet</div>
        </div>
      </div>

      <div className="container" style={{ maxWidth: '600px' }}>
        <h1>{sheet.title}</h1>
        <p>{sheet.location}</p>
        <p>{sheet.dates.join(' - ')}</p>

        {error && <div className="error">{error}</div>}
        {success && <div className="success">{success}</div>}

        {!isGuest && user ? (
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Name</label>
              <input type="text" value={name} disabled />
            </div>

            <div className="form-group">
              <label>Email</label>
              <input type="email" value={email} disabled />
            </div>

            <div className="form-group">
              <label>Dates Attended</label>
              <div className="checkbox-group">
                {sheet.dates.map(date => (
                  <label key={date}>
                    <input
                      type="checkbox"
                      checked={selectedDates.includes(date)}
                      onChange={() => handleDateToggle(date)}
                    />
                    {date}
                  </label>
                ))}
              </div>
            </div>

            <div className="form-group">
              <label>Signature</label>
              <div className="canvas-container">
                <canvas
                  ref={canvasRef}
                  width={550}
                  height={150}
                  onMouseEnter={initSignaturePad}
                />
              </div>
              <button type="button" onClick={handleClearSignature} style={{ marginTop: '10px' }}>
                Clear Signature
              </button>
            </div>

            <button type="submit" disabled={loading}>
              {loading ? 'Submitting...' : 'Submit Signature'}
            </button>
          </form>
        ) : (
          <>
            {!isGuest && !user && (
              <div style={{ marginBottom: '20px' }}>
                <p>Do you have a KSB account?</p>
                <button onClick={() => (window.location.href = '/login')}>
                  Yes, Login
                </button>
                <button
                  onClick={() => setIsGuest(true)}
                  style={{ marginLeft: '10px', background: '#6c757d' }}
                >
                  No, Sign as Guest
                </button>
              </div>
            )}

            {isGuest && (
              <form onSubmit={handleSubmit}>
                <div className="form-group">
                  <label>Name</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                </div>

                <div className="form-group">
                  <label>Email</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>

                <div className="form-group">
                  <label>Dates Attended</label>
                  <div className="checkbox-group">
                    {sheet.dates.map(date => (
                      <label key={date}>
                        <input
                          type="checkbox"
                          checked={selectedDates.includes(date)}
                          onChange={() => handleDateToggle(date)}
                        />
                        {date}
                      </label>
                    ))}
                  </div>
                </div>

                <div className="form-group">
                  <label>Signature</label>
                  <div className="canvas-container">
                    <canvas
                      ref={canvasRef}
                      width={550}
                      height={150}
                      onMouseEnter={initSignaturePad}
                    />
                  </div>
                  <button type="button" onClick={handleClearSignature} style={{ marginTop: '10px' }}>
                    Clear Signature
                  </button>
                </div>

                <button type="submit" disabled={loading}>
                  {loading ? 'Submitting...' : 'Submit Signature'}
                </button>
              </form>
            )}
          </>
        )}
      </div>
    </div>
  );
}

export default SigningSheet;
